//
//  Flora_s_GardenApp.swift
//  Flora's Garden
//
//  Created by Mariia Chemerys on 19.10.2023.
//

import SwiftUI

@main
struct Flora_s_GardenApp: App {
    var body: some Scene {
        WindowGroup {
           MainMenuView()
        }
    }
}
